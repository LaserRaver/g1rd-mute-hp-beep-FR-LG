-- Mute Low HP Beep (FireRed/LeafGreen) v1.0.4
--
-- FRLG does not route its battle low-HP alarm through the generic
-- mod.content.sfx registry.  Gen1Recomp's Gen 3 audio engine ultimately
-- starts the effect through game3.audio.Audio.playSe().
--
-- This mod patches that live playback entry point and consumes only
-- SE_LOW_HEALTH (ID 83 in the FRLG sound table).  Every other sound is
-- passed through unchanged.
--
-- engine_internals is required because Audio is not currently exposed as a
-- public mod hook.  The patch is deliberately narrow and keeps the original
-- function intact for every other SFX.

return function(mod)
  local Audio = require("src.core.game3.audio")
  local SE = require("src.core.game3.se_ids")

  if type(Audio) ~= "table" or type(Audio.playSe) ~= "function" then
    mod.log:error("FRLG audio API unavailable; low-HP beep was not muted")
    return
  end

  local originalPlaySe = Audio.playSe
  local lowHpId = SE.SE_LOW_HEALTH

  -- Avoid wrapping twice if the mod is reloaded by the manager.
  if Audio.__muteLowHpBeep_v104 then
    return
  end
  Audio.__muteLowHpBeep_v104 = true

  Audio.playSe = function(id, opts)
    local resolved = SE.resolve(id)
    if resolved == lowHpId then
      -- Pretend the sound was handled.  This prevents the M4A player from
      -- ever creating the looping low-HP source.
      return true
    end
    return originalPlaySe(id, opts)
  end

  mod.log:info("FRLG low-HP alarm muted (SE_LOW_HEALTH=%s)", tostring(lowHpId))
end
