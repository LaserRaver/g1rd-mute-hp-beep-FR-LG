# Mute Low HP Beep (FRLG) v1.0.4

This version targets FireRed and LeafGreen specifically.

When the mod is enabled, the Gen 3 audio engine's `playSe()` entry point is
patched so `SE_LOW_HEALTH` is consumed without starting an audio source.
All other sound effects are passed to the original audio function unchanged.

This intentionally does not add a menu item or setting: enabled means muted.

Requires Gen1Recomp 0.3.33+ and the FRLG Gen 3 engine with `engine_internals`
mod permission support.
